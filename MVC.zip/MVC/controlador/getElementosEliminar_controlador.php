<?php 
	
	$id = $_GET['id'];
	

	require_once('../modelo/queryEliminar_modelo.php');
	eliminarDatos($id);


 ?>