<?php 
	
	$id = $_POST['id'];
	$nombre = $_POST['nombre'];
	$edad = $_POST['edad'];
	$escolaridad  = $_POST['escolaridad'];

	require_once('../modelo/queryModificar_modelo.php');
	modificarDatos($id, $nombre, $edad,$escolaridad);

 ?>