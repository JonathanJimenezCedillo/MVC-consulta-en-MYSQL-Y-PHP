<?php
	

	$nombreE = $_POST['nombre'];
	$edadE = $_POST['edad'];
	$escolaridadE = $_POST['escolaridad'];
	
	

	require_once("../modelo/queryInsertar_modelo.php");
	if ($resultado) {
		header("Location:../");
	}
	else{
		die("ERROR AL INSERTAR LOS DATOS");
	}
?>