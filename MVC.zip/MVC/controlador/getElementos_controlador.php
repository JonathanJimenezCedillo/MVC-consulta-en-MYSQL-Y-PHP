<?php
	
	$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : null;
	$edad =isset($_POST['edad']) ? $_POST['edad'] : null;
	$escolaridad = isset($_POST['escolaridad']) ? $_POST['escolaridad'] : null;

	require_once("../modelo/queryInsertar_modelo.php");
	insertarDatos($nombre, $edad, $escolaridad);


?>