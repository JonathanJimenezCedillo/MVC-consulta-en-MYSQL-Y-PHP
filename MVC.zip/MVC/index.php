<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="vista/css/bootstrap.min.css">
		<link rel="stylesheet" href="vista/css/bootstrap-grid.css">
		<link rel="stylesheet" href="vista/css/bootstrap-reboot.min.css">


		<title>Recursos Humanos</title>

	</head>
	<body>

		<header style="width: 260px; margin: 0 auto;">
			<div class="container ">
			<div class="row">
				<h1 style="text-align: center;">Prueba MVC</h1>
			</div>
		</div>
		</header>


		<div class="container">
			<div class="row">
				<form style="margin: 0 auto;" method="POST" action="controlador/getElementos_controlador.php">
					<label>Nombre</label>
					<input type="text" id="nombre" name="nombre" />
					<label>Edad</label>
					<input type="text" id="edad" name="edad" />
					<label>Escolaridad</label>
					<input type="text" id="escolaridad" name="escolaridad" />
					<input type="submit" value="Submit"/>
				</form>
			</div>
		</div>
		<br>
		<div class="container" id="main" style="text-align: center;">
			<div class="row table-responsive" style="text-align: center;">

				<?php
					require_once "vista/tablaMostrar_vista.php";
				?>
			</div>
		</div>

		


		
		 <script type="text/javascript" src="vista/js/jquery-3.4.1.min.js"></script>
		<script type="text/javascript" src="vista/js/bootstrap.min.js"></script>
		<script src="https://kit.fontawesome.com/6e52167165.js" crossorigin="anonymous"></script>
		<script src="vista/js/ajax.js"></script>

	</body>
	</html>