<?php 
	
	class Conectar{	

	 function conexion()
		{
			$conexiónBDS =  mysqli_connect('localhost','root','','prueba');
			return $conexiónBDS;
		}

		function cerrarConexion(){
			/*en la siguiente variables, las igualremos a null, con ello cuando
			términe de ejecutar la consulta, la conexión y la consulta realizada se quedará vacias,
			logrando que no exita y no halla, bugs*/
			$conexiónBDS=null;
			$sql=null;
		}

		
	}	
	



?>
