<?php 
	
	class Conectar{		
	 function conexion()
		{
			$conexiónBDS =  mysqli_connect('localhost','root','','prueba');
			return $conexiónBDS;
		}
	}	
	



?>
