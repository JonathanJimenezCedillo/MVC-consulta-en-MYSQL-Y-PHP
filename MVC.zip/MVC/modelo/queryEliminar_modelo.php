<?php 
	
	 function eliminarDatos($id){

		require_once("conexion/conexion.php");
		$conexion=new Conectar;
		
		$sql = "DELETE FROM tablaprueba WHERE id = $id;";
		$resultado = mysqli_query($conexion->conexion(), $sql);

		if ($resultado) {
				echo("Modificación  realizada correctamente <br>");
				echo "<a href='../MVC/'>Regresar</a>";
		}else{
				echo("Modificación no realizada correctamente");
		}

		$conexion->cerrarConexion();
	}
	

 ?>
