<<?php 
	
	require_once("conexion/conexion.php");
	$conexion=new Conectar;
	$sql = "INSERT INTO tablaprueba VALUES(null,'$nombreE',$edadE,'$escolaridadE')";
	$resultado = mysqli_query($conexion->conexion(), $sql);

 ?>