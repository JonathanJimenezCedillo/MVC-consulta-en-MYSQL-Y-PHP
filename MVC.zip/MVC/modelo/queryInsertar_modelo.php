<?php 

	function insertarDatos($nombreE, $edadE, $escolaridadE){
		require_once("conexion/conexion.php");
	
		$conexion=new Conectar;
		
		$sql = "INSERT INTO tablaprueba VALUES(null,'$nombreE','$edadE','$escolaridadE');";
		$resultado = mysqli_query($conexion->conexion(), $sql);

		if ($resultado) {
			echo ("Datos Insertados Correctamente");
			echo "<a href='../MVC/'>Regresar</a>";
			}
		else{
			die("Datos No Insertados Correctamente");
		}
		$conexion->cerrarConexion();

	}


 ?>
 

