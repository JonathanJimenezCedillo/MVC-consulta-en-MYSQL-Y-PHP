<?php 
	
	 function modificarDatos($id, $nombre, $edad, $escolaridad){

		require_once("conexion/conexion.php");
		$conexion=new Conectar;
		
		$sql = "UPDATE tablaprueba SET nombre ='$nombre',edad ='$edad',
		escolaridad ='$escolaridad' WHERE id = $id;";
		$resultado = mysqli_query($conexion->conexion(), $sql);

		if ($resultado) {
				echo("Modificación  realizada correctamente <br>");
				echo "<a href='../MVC/'>Regresar</a>";
		}else{
				echo("Modificación no realizada correctamente");
		}

		$conexion->cerrarConexion();
	}
	

 ?>
