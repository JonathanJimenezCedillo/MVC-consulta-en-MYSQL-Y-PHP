<?php

 function datosMostrar()
{
	require_once("conexion/conexion.php");
	$conexion=new Conectar;
	
	$sql = "SELECT * FROM tablaprueba";
	$resultado = mysqli_query($conexion->conexion(),$sql);

	return $resultado;

	$conexion->cerrarConexion();

	
}

 function datosMostrarId($id)
{
	require_once("conexion/conexion.php");
	$conexion=new Conectar;
	$sql = "SELECT * FROM tablaprueba WHERE id='$id'";
	$resultado = mysqli_query($conexion->conexion(),$sql);

	return $resultado;
	$conexion->cerrarConexion();
	
}
	

?>