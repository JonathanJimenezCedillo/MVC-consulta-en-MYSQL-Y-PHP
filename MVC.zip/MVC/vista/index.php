<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="vista/css/bootstrap.min.css">
		<link rel="stylesheet" href="vista/css/bootstrap.grid.css">
		<link rel="stylesheet" href="vista/css/bootstrap-reboot.min.css">
		
		<title>Recursos Humanos</title>

	</head>
	<body style="text-align: center;">
		
		<div class="container">
			<div class="row">
				<h1 style="text-align: center; ">RECURSOS HUMANOS</h1>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<form class="form-group"  method="POST" action="../controlador/getElementos_controlador.php">
					<label>Nombre</label>
					<input type="text" id="nombre" name="nombre" />
					<label>Edad</label>
					<input type="text" id="edad" name="edad" />
					<label>Escolaridad</label>
					<input type="text" id="escolaridad" name="escolaridad" />
					<input class="btn btn-primary" type="submit" value="Submit"/>	
				</form>
			</div>
		</div>

		<script type="text/javascript" src="vista/js/jquery-3.4.1.min.js"></script>
		<script type="text/javascript" src="vista/js/bootstrap.min.js"></script>
	</body>
	</html>	