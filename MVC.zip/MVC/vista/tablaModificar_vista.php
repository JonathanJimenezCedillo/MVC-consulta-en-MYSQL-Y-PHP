<?php 
	require_once('../modelo/queryMostrar_modelo.php');
	$id = $_GET['id'];
	$resultado = datosMostrarId($id);
	$fila = mysqli_fetch_assoc($resultado);
	
 ?>

		
		<div class="container">
			<div class="row">
				<form style="margin: 0 auto;" method="POST"  id="formulario">
					<h1 style="text-align: center;">Modificar Datos</h1>
					<label >Id</label>
					<input type="text" id="id" name="id" value="<?php echo $fila['id'] ?>"/>
					<label>Nombre</label>
					<input type="text" id="nombre" name="nombre" value="<?php echo $fila['nombre'] ?>"/>
					<label>Edad</label>
					<input type="text" id="edad" name="edad" value="<?php echo $fila['edad'] ?>"/>
					<label>Escolaridad</label>
					<input type="text" id="escolaridad" name="escolaridad" value="<?php echo $fila['escolaridad'] ?>"/>
					<input type="button" value="Modificar" onclick="ejecutarAjaxModifiar(<?php echo $fila['escolaridad'] ?>)" id="modificar" />
				</form>
			</div>
		</div>
