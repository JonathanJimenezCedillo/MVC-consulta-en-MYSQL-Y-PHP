<?php
require_once "modelo/queryMostrar_modelo.php";
$resultado = datosMostrar();
?>

	
	<table id="tabla" class="table table-striped" border="1">
		<h2 style="text-align: center; margin: 0 auto;"> Mostrar Datos</h2>
		<thead>
			<tr>
				<th>ID</th>
				<th>Nombre</th>
				<th>Edad</th>
				<th>Escolaridad</th>
			</tr>
		</thead>

		<tbody>
			<?php while ($fila = mysqli_fetch_array($resultado)) {?>
			<tr>
				<td ><?php echo $fila['id'] ?></td>
				<td ><?php echo $fila['nombre'] ?></td>
				<td ><?php echo $fila['edad'] ?></td>
				<td ><?php echo $fila['escolaridad'] ?></td>
				<td><button onclick="ejecutarAjax(<?php echo $fila['id'] ?>)" id="modificar" class="fas fa-pen  btn btn-success"> </button></td>
				<!-- Hacemos que el boton ejecute la función al presionarlo enviando el ID como parámetro -->
				<td><button onclick="ejecutarAjaxEliminar(<?php echo $fila['id'] ?>)"id="eliminar" class="fas fa-trash-alt btn btn-danger"></button>
				</td>
			</tr>
			<?php }?>
		</tbody>



